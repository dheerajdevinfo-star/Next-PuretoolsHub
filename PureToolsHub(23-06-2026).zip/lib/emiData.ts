export type LoanType = "home" | "car" | "personal" | "emi"

export const emiConfig = {
  emi: {
    loanTypeKey: "emi" as LoanType,
    title: "EMI Calculator",
    description: "Kisi bhi loan ka monthly EMI, total interest aur repayment schedule instantly calculate karein — bilkul free.",
    keywords: [
      "EMI calculator",
      "EMI calculator India",
      "loan EMI calculator",
      "monthly EMI calculator",
      "online EMI calculator",
      "EMI calculator 2025",
    ],
    minAmount: 10000,
    maxAmount: 10000000,
    defaultAmount: 1000000,
    step: 10000,
    minRate: 1,
    maxRate: 36,
    defaultRate: 10.0,
    minTenure: 1,
    maxTenure: 30,
    defaultTenure: 5,
    amountLabel: "Loan amount",
    amountHints: ["₹10K", "₹1 crore"],
    banks: [
      { name: "SBI", rate: 9.00 },
      { name: "HDFC", rate: 9.20 },
      { name: "ICICI", rate: 10.80 },
      { name: "Axis", rate: 11.25 },
    ],
    faqs: [
      {
        q: "EMI kya hoti hai?",
        a: "EMI (Equated Monthly Instalment) woh fixed monthly amount hai jo aap bank ko loan chukane ke liye dete hain. Isme principal aur interest dono shamil hote hain."
      },
      {
        q: "EMI kaise calculate hoti hai?",
        a: "EMI = P × r × (1+r)^n ÷ [(1+r)^n - 1] formula se calculate hoti hai. P = loan amount, r = monthly interest rate, n = tenure in months. Upar diya calculator automatically ye karta hai."
      },
      {
        q: "Kya EMI kam kar sakte hain?",
        a: "Haan — tenure badhane se EMI kam hoti hai lekin total interest zyada lagta hai. Ya phir down payment badhakar loan amount kam karein."
      },
      {
        q: "Prepayment karna chahiye?",
        a: "Haan, prepayment se interest ki badi bachat hoti hai. Floating rate loans pe RBI ke niyam anusaar koi prepayment penalty nahi hoti."
      },
    ],
    relatedTools: [
      { label: "Home Loan EMI", href: "/finance/emi/home-loan",  description: "Calculate your home loan EMI instantly." },
      { label: "Car Loan EMI", href: "/finance/emi/car-loan",  description: "Calculate car loan monthly installments."},
      { label: "Personal Loan EMI", href: "/finance/emi/personal-loan", description: "Estimate personal loan EMI and interest." },
    ],
  },

  home: {
    loanTypeKey: "home" as LoanType,
    title: "Home Loan EMI Calculator",
    description: "India ke sabse accurate home loan EMI calculator — monthly EMI, total interest aur amortization schedule instantly dekhein.",
    keywords: [
      "home loan EMI calculator",
      "home loan EMI calculator India",
      "SBI home loan EMI calculator",
      "HDFC home loan EMI calculator",
      "housing loan EMI calculator",
      "ghar ka loan EMI calculator",
    ],
    minAmount: 100000,
    maxAmount: 10000000,
    defaultAmount: 5000000,
    step: 50000,
    minRate: 6,
    maxRate: 20,
    defaultRate: 8.5,
    minTenure: 1,
    maxTenure: 30,
    defaultTenure: 20,
    amountLabel: "Loan amount",
    amountHints: ["₹1 lakh", "₹1 crore"],
    banks: [
      { name: "SBI", rate: 8.50 },
      { name: "HDFC", rate: 8.70 },
      { name: "ICICI", rate: 8.75 },
      { name: "Axis", rate: 8.80 },
    ],
    faqs: [
      {
        q: "Home loan EMI kaise calculate karte hain?",
        a: "EMI = P × r × (1+r)^n ÷ [(1+r)^n - 1] formula se calculate hoti hai. Upar diya calculator automatically ye calculation karta hai."
      },
      {
        q: "SBI home loan interest rate 2025 mein kitni hai?",
        a: "SBI home loan interest rate currently 8.50% se shuru hoti hai. Ye rate aapke CIBIL score aur loan amount par depend karta hai."
      },
      {
        q: "Loan tenure lamba lena chahiye ya chhota?",
        a: "Lamba tenure lene se monthly EMI kam hoti hai lekin total interest zyada bharna padta hai. Calculator se dono compare karein."
      },
    ],
    relatedTools: [
      { label: "Car Loan EMI", href: "/finance/emi/car-loan", description: 'Car loan EMI nikaalein', },
      { label: "Personal Loan EMI", href: "/finance/emi/personal-loan", description: 'Personal loan compare karein' },
      { label: "SIP Calculator", href: "/finance/sip", description: 'Investments plan karein' },
    ],
  },

  car: {
    loanTypeKey: "car" as LoanType,
    title: "Car Loan EMI Calculator",
    description: "Car loan ka monthly EMI, total interest aur repayment schedule instantly calculate karein — bilkul free.",
    keywords: [
      "car loan EMI calculator",
      "car loan EMI calculator India",
      "auto loan EMI calculator",
      "vehicle loan calculator",
      "SBI car loan EMI calculator",
      "HDFC car loan EMI calculator",
    ],
    minAmount: 50000,
    maxAmount: 5000000,
    defaultAmount: 800000,
    step: 10000,
    minRate: 7,
    maxRate: 20,
    defaultRate: 9.0,
    minTenure: 1,
    maxTenure: 7,
    defaultTenure: 5,
    amountLabel: "Car loan amount",
    amountHints: ["₹50K", "₹50 lakh"],
    banks: [
      { name: "SBI", rate: 9.00 },
      { name: "HDFC", rate: 9.20 },
      { name: "ICICI", rate: 9.25 },
      { name: "Axis", rate: 9.30 },
    ],
    faqs: [
      {
        q: "Car loan EMI kaise calculate karein?",
        a: "EMI = P × r × (1+r)^n ÷ [(1+r)^n - 1] formula use hota hai. Slider se amount, rate aur tenure set karein — EMI automatically calculate ho jaayegi."
      },
      {
        q: "Car loan ke liye minimum CIBIL score kitna chahiye?",
        a: "Zyaadatar banks 700+ CIBIL score prefer karte hain car loan ke liye."
      },
      {
        q: "New car ya used car — kaunse pe loan sasta hai?",
        a: "New car loan ka interest rate generally kam hota hai (8–10%) jabki used car loan thoda zyada (12–16%) hota hai."
      },
    ],
    relatedTools: [
      { label: "Home Loan EMI", href: "/finance/emi/home-loan", description: 'Ghar ka EMI calculate karein', },
      { label: "Personal Loan EMI", href: "/finance/emi/personal-loan", description: 'Personal loan compare karein' },
      { label: "FD Calculator", href: "/finance/fd",  description: "Calculate car loan monthly installments." },
    ],
  },

  personal: {
    loanTypeKey: "personal" as LoanType,
    title: "Personal Loan EMI Calculator",
    description: "Personal loan ka monthly EMI instantly calculate karein — bina kisi collateral ke milne wale loan ki planning karein.",
    keywords: [
      "personal loan EMI calculator",
      "personal loan calculator India",
      "instant loan EMI calculator",
      "unsecured loan calculator",
      "SBI personal loan EMI calculator",
    ],
    minAmount: 10000,
    maxAmount: 5000000,
    defaultAmount: 500000,
    step: 5000,
    minRate: 8,
    maxRate: 36,
    defaultRate: 12.0,
    minTenure: 1,
    maxTenure: 5,
    defaultTenure: 3,
    amountLabel: "Loan amount",
    amountHints: ["₹10K", "₹50 lakh"],
    banks: [
      { name: "SBI", rate: 11.00 },
      { name: "HDFC", rate: 10.50 },
      { name: "ICICI", rate: 10.80 },
      { name: "Axis", rate: 11.25 },
    ],
    faqs: [
      {
        q: "Personal loan kitni jaldi milta hai?",
        a: "Digital banks aur NBFCs 24–48 ghante mein personal loan approve kar dete hain."
      },
      {
        q: "Personal loan ke liye kya documents chahiye?",
        a: "Aadhaar, PAN, 3 mahine ki salary slip, 6 mahine ka bank statement aur address proof chahiye hota hai."
      },
      {
        q: "Kya personal loan prepay kar sakte hain?",
        a: "Haan, lekin zyaadatar banks 6–12 EMI ke baad hi prepayment allow karte hain aur 2–5% penalty lagate hain."
      },
    ],
    relatedTools: [
      { label: "Home Loan EMI", href: "/finance/emi/home-loan", description: 'Ghar ka EMI calculate karein' },
      { label: "Car Loan EMI", href: "/finance/emi/car-loan", description: 'Car loan EMI nikaalein' },
      { label: "SIP Calculator", href: "/finance/sip", description: 'Investments plan karein' },
    ],
  },
}

// Slug to loanType mapping — page.tsx mein use hoga
export const slugToLoanType: Record<string, LoanType> = {
  "home-loan": "home",
  "car-loan": "car",
  "personal-loan": "personal",
}

// Valid slugs — generateStaticParams mein use hoga
export const validEmiSlugs = Object.keys(slugToLoanType)