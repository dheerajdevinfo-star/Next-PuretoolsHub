export type CiType = "compound-interest" | "simple-interest" | "cagr" | "inflation"

export const ciConfig = {

  "compound-interest": {
    ciTypeKey:        "compound-interest" as CiType,
    title:            "Compound Interest Calculator",
    description:      "Kisi bhi investment par compound interest aur maturity amount instantly calculate karein — monthly, quarterly, yearly compounding ke saath.",
    keywords:         ["compound interest calculator", "compound interest calculator India", "CI calculator", "compound interest formula calculator", "online compound interest calculator 2025"],
    defaultPrincipal: 100000,
    minPrincipal:     1000,
    maxPrincipal:     10000000,
    stepPrincipal:    1000,
    defaultRate:      10,
    minRate:          1,
    maxRate:          30,
    defaultTenure:    5,
    minTenure:        1,
    maxTenure:        30,
    compounding:      ["Monthly", "Quarterly", "Half-yearly", "Yearly"],
    faqs: [
      { q: "Compound interest kya hota hai?",              a: "Compound interest mein aapko sirf principal par nahi balki accumulated interest par bhi interest milta hai. Isi wajah se long term mein wealth bahut tezi se badhti hai." },
      { q: "Compound interest formula kya hai?",           a: "A = P × (1 + r/n)^(n×t) — jahan P principal hai, r annual rate hai, n compounding frequency hai aur t time in years hai." },
      { q: "Monthly aur yearly compounding mein fark?",    a: "Monthly compounding mein zyada baar interest calculate hota hai isliye return thoda zyada hota hai. ₹1 lakh par 10% rate se 5 saal mein monthly compounding yearly se zyada deta hai." },
      { q: "Compound interest simple interest se better?", a: "Long term ke liye haan — jitna lamba tenure, utna zyada fark. 20+ saal mein compound interest simple interest se 2–3 guna zyada ho sakta hai." },
    ],
    relatedTools: [
      { label: "Simple Interest",  href: "/finance/compound-interest/simple-interest" },
      { label: "CAGR Calculator",  href: "/finance/compound-interest/cagr"            },
      { label: "Inflation Calculator", href: "/finance/compound-interest/inflation"   },
    ],
  },

  "simple-interest": {
    ciTypeKey:        "simple-interest" as CiType,
    title:            "Simple Interest Calculator",
    description:      "Loan ya investment par simple interest aur total amount instantly calculate karein — SI formula ke saath step-by-step.",
    keywords:         ["simple interest calculator", "simple interest calculator India", "SI calculator", "simple interest formula calculator", "simple interest vs compound interest"],
    defaultPrincipal: 100000,
    minPrincipal:     1000,
    maxPrincipal:     10000000,
    stepPrincipal:    1000,
    defaultRate:      10,
    minRate:          1,
    maxRate:          30,
    defaultTenure:    5,
    minTenure:        1,
    maxTenure:        30,
    compounding:      [],
    faqs: [
      { q: "Simple interest kya hota hai?",          a: "Simple interest sirf original principal par calculate hota hai — har saal same amount ka interest milta hai. SI = P × R × T / 100." },
      { q: "SI aur CI mein kya fark hai?",           a: "SI mein sirf principal par interest milta hai. CI mein principal + pichle interest par bhi interest milta hai, isliye CI zyada hota hai." },
      { q: "Simple interest kahan use hota hai?",    a: "Short term loans, car loans, aur kuch personal loans mein simple interest method use hota hai." },
      { q: "Simple interest ka formula kya hai?",    a: "SI = P × R × T / 100. Jahan P = principal, R = annual rate, T = time in years. Total amount = P + SI." },
    ],
    relatedTools: [
      { label: "Compound Interest", href: "/finance/compound-interest"              },
      { label: "CAGR Calculator",   href: "/finance/compound-interest/cagr"         },
      { label: "EMI Calculator",    href: "/finance/emi"                            },
    ],
  },

  "cagr": {
    ciTypeKey:        "cagr" as CiType,
    title:            "CAGR Calculator — Compound Annual Growth Rate",
    description:      "Investment ka CAGR instantly calculate karein — mutual funds, stocks aur business growth ka accurate annual return jaanein.",
    keywords:         ["CAGR calculator", "CAGR calculator India", "compound annual growth rate calculator", "mutual fund CAGR calculator", "investment return calculator"],
    defaultPrincipal: 100000,
    minPrincipal:     1000,
    maxPrincipal:     10000000,
    stepPrincipal:    1000,
    defaultRate:      0,        // CAGR calculated from values
    minRate:          0,
    maxRate:          100,
    defaultTenure:    5,
    minTenure:        1,
    maxTenure:        30,
    compounding:      [],
    faqs: [
      { q: "CAGR kya hota hai?",                    a: "CAGR (Compound Annual Growth Rate) batata hai ki aapki investment har saal average kitne % se badhi. Ye fluctuating returns ko ek smooth annual rate mein convert karta hai." },
      { q: "CAGR formula kya hai?",                 a: "CAGR = (Ending Value / Beginning Value)^(1/n) - 1. Jahan n = number of years. Calculator automatically ye calculate karta hai." },
      { q: "Good CAGR kitna hota hai?",             a: "Equity mutual funds ke liye 12–15% CAGR achha maana jaata hai. Fixed deposits 6–8% CAGR deti hain. Index funds historically 12% CAGR dete hain." },
      { q: "CAGR aur absolute return mein fark?",   a: "Absolute return sirf total % gain batata hai. CAGR per year ka average gain batata hai — investment comparison ke liye CAGR zyada useful hai." },
    ],
    relatedTools: [
      { label: "Compound Interest",  href: "/finance/compound-interest"               },
      { label: "SIP Calculator",     href: "/finance/sip"                             },
      { label: "Lumpsum Calculator", href: "/finance/sip/lumpsum"                     },
    ],
  },

  "inflation": {
    ciTypeKey:        "inflation" as CiType,
    title:            "Inflation Calculator",
    description:      "Mehngai ka asar calculate karein — aaj ke ₹1 lakh ki 10–20 saal baad kitni value hogi, instantly jaanein.",
    keywords:         ["inflation calculator", "inflation calculator India", "purchasing power calculator", "inflation rate calculator India 2025", "future value inflation calculator"],
    defaultPrincipal: 100000,
    minPrincipal:     1000,
    maxPrincipal:     10000000,
    stepPrincipal:    1000,
    defaultRate:      6,        // India avg inflation ~6%
    minRate:          1,
    maxRate:          20,
    defaultTenure:    10,
    minTenure:        1,
    maxTenure:        30,
    compounding:      ["Yearly"],
    faqs: [
      { q: "Inflation calculator kaise use karein?",   a: "Current amount, expected inflation rate aur time period set karein — calculator batayega ki aaj ki raqam future mein kitne ki barabar hogi." },
      { q: "India mein average inflation rate kitna?", a: "India mein historically average CPI inflation 5–7% rahi hai. RBI ka target 4% (+/- 2%) hai." },
      { q: "Inflation se paisa bachane ka tarika?",    a: "Equity mutual funds, real estate, aur gold inflation se upar return dete hain historically. FD aksar inflation beat nahi kar paati." },
      { q: "Retirement planning mein inflation?",      a: "Agar aaj ₹50,000/month kharcha hai to 6% inflation par 20 saal baad ₹1.6 lakh/month chahiye hoga. Isliye retirement corpus mein inflation factor zaroori hai." },
    ],
    relatedTools: [
      { label: "Compound Interest",  href: "/finance/compound-interest"             },
      { label: "SIP Calculator",     href: "/finance/sip"                           },
      { label: "FD Calculator",      href: "/finance/fd"                            },
    ],
  },
}

export const slugToCiType: Record<string, CiType> = {
  "simple-interest": "simple-interest",
  "cagr":            "cagr",
  "inflation":       "inflation",
}

export const validCiSlugs = Object.keys(slugToCiType)