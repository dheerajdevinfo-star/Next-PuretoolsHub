import { emiConfig } from "@/lib/emiData"
import EMICalculator from "@/components/ui/EMICalculator"
import Faq from "@/components/ui/Faq"
import RelatedTools from "@/components/ui/RelatedTools"

const config = emiConfig["emi"]  // ✅ bas yahi line

export const metadata = {
  title: config.title,
  description: config.description,
  keywords: config.keywords,
}

export default function EMIIndexPage() {
  const faqData = config.faqs.map(f => ({ question: f.q, answer: f.a }))
  const relatedToolsData = config.relatedTools.map(t => ({
    title: t.label,
    description: t.label,
    link: t.href,
  }))

  return (
    <>
      <section className="heding_section">
        <div className="max-width">
          <h1 className="heading">{config.title}</h1>
          <p className="pairagraph">{config.description}</p>
        </div>
      </section>

      <section>
        <div className="max-width">
          <EMICalculator loanType="emi" />  {/* ✅ generic calculator */}
        </div>
      </section>

      <section className="calculator_faq">
        <div className="max-width">
          <h2 className="hpme_faq_h2">Aksar puchhe jaane wale sawaal</h2>
          <Faq
            title={config.title}
            description={config.description}
            faqs={faqData}
          />
        </div>
      </section>

      <section className="related_tools">
        <div className="max-width">
          <h2 className="subtitle">Related calculators</h2>
          <RelatedTools tools={relatedToolsData} />
        </div>
      </section>
    </>
  )
}