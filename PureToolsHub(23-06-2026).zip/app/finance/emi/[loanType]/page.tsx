import EMICalculator from "@/components/ui/EMICalculator"
import { emiConfig, slugToLoanType, validEmiSlugs } from "@/lib/emiData"
import { notFound } from "next/navigation"
import Breadcrumb from "@/components/ui/Breadcrumb"
import Faq from "@/components/ui/Faq"
import RelatedTools from "@/components/ui/RelatedTools"

type Props = {
  params: Promise<{ loanType: string }>
}

export async function generateMetadata({ params }: Props) {
  const { loanType } = await params
  const key = slugToLoanType[loanType]
  const config = emiConfig[key]
  console.log(key)
  if (!config) return {}

  return {
    title: config.title,
    description: config.description,
    keywords: config.keywords,
    openGraph: {
      title: config.title,
      description: config.description,
      url: `https://puretoolhub.com/finance/emi/${loanType}`,
    },
  }
}

export function generateStaticParams() {
  return validEmiSlugs.map(slug => ({ loanType: slug }))
}

export default async function Page({ params }: Props) {
  const { loanType } = await params
  if (!validEmiSlugs.includes(loanType)) notFound()

  const key = slugToLoanType[loanType]
  const config = emiConfig[key]  // ✅ emiData.ts ka data yahan aaya

  // ✅ emiData.ts ke faqs ko Faq component ke format mein convert karein
  const faqData = config.faqs.map(faq => ({
    question: faq.q,
    answer: faq.a,
  }))

  // ✅ emiData.ts ke relatedTools ko RelatedTools component ke format mein convert karein
  const relatedToolsData = config.relatedTools.map(tool => ({
    title: tool.label,
    description: tool.description,   // agar description nahi hai emiData mein
    link: tool.href,
  }))

  return (
    <>
      <Breadcrumb />

      {/* ✅ Hardcoded text hata ke config se dynamic text */}
      <section className="heding_section">
        <div className="max-width">
          <h1 className="heading">{config.title}</h1>
          <p className="pairagraph">{config.description}</p>
        </div>
      </section>

      <section>
        <div className="max-width">
          <EMICalculator loanType={key} />
        </div>
      </section>

      <section className="calculator_detials_box">
        <div className="max-width">
          <h2 className="subtitle">{config.title} — kaise kaam karta hai?</h2>
          <p className="pairagraph">
            {config.title} ek free online tool hai jo aapke loan amount, interest rate aur
            tenure ke basis pe exact monthly EMI calculate karta hai.
          </p>

          <div className="formula_box">
            <h2>EMI formula</h2>
            <h3>EMI = P × r × (1+r)^n ÷ [(1+r)^n - 1]</h3>
            <p className="pairagraph">
              P = Principal loan amount &nbsp;|&nbsp; r = Monthly interest rate &nbsp;|&nbsp; n = Loan tenure in months
            </p>
          </div>
        </div>
      </section>

      {/* ✅ emiData.ts ke faqs yahan */}
      <section className="calculator_faq">
        <div className="max-width">
          <h2 className="hpme_faq_h2">Aksar puchhe jaane wale sawaal</h2>
          <Faq
            title={`${config.title} FAQs`}
            description={`${config.title} se jude common sawaal aur jawaab.`}
            faqs={faqData}
          />
        </div>
      </section>

      {/* ✅ emiData.ts ke relatedTools yahan */}
      <section className="related_tools">
        <div className="max-width">
          <h2 className="subtitle">Related calculators</h2>
          <RelatedTools tools={relatedToolsData} />
        </div>
      </section>
    </>
  )
}