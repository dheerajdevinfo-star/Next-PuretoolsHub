import Link from "next/link"
import Breadcrumb from "@/components/ui/Breadcrumb"
import Faq from "@/components/ui/Faq"
import RelatedTools from "@/components/ui/RelatedTools"
import CICalculator from "@/components/ui/CICalculator"
import { ciConfig } from "@/lib/ciData"

const config = ciConfig["compound-interest"]

export const metadata = {
  title: config.title,
  description: config.description,
  keywords: config.keywords,
}

const ciCards = [
  { slug: "simple-interest", emoji: "📊", key: "simple-interest" as const },
  { slug: "cagr",            emoji: "📈", key: "cagr"            as const },
  { slug: "inflation",       emoji: "💸", key: "inflation"       as const },
]

export default function CIIndexPage() {
  const faqData = config.faqs.map(f => ({ question: f.q, answer: f.a }))
  const relatedToolsData = config.relatedTools.map(t => ({
    title: t.label, description: t.label, link: t.href,
  }))

  return (
    <>
      <Breadcrumb />

      <section className="heding_section">
        <div className="max-width">
          <h1 className="heading">{config.title}</h1>
          <p className="pairagraph">{config.description}</p>
        </div>
      </section>

      <section>
        <div className="max-width">
          <CICalculator ciType="compound-interest" />
        </div>
      </section>

      <section>
        <div className="max-width">
          <h2 className="subtitle">Related calculators</h2>
          <div className="emi_index_grid">
            {ciCards.map(({ slug, emoji, key }) => {
              const c = ciConfig[key]
              return (
                <Link href={`/finance/compound-interest/${slug}`} key={slug} className="emi_index_card">
                  <span className="emi_index_emoji">{emoji}</span>
                  <h2 className="emi_index_title">{c.title}</h2>
                  <p className="emi_index_desc">{c.description}</p>
                  <span className="emi_index_cta">Calculate karein →</span>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      <section className="calculator_detials_box">
        <div className="max-width">
          <h2 className="subtitle">Compound Interest kaise calculate hota hai?</h2>
          <p className="pairagraph">
            Compound interest mein principal ke saath-saath pichle periods ke
            interest par bhi interest milta hai. Yahi "interest on interest"
            long term mein wealth ko exponentially badhata hai.
          </p>
          <div className="formula_box">
            <h2>Compound Interest Formula</h2>
            <h3>A = P × (1 + r/n)^(n×t)</h3>
            <p className="pairagraph">
              P = Principal &nbsp;|&nbsp; r = Annual rate &nbsp;|&nbsp;
              n = Compounding frequency &nbsp;|&nbsp; t = Time in years
            </p>
          </div>
        </div>
      </section>

      <section className="calculator_faq">
        <div className="max-width">
          <h2 className="hpme_faq_h2">Aksar puchhe jaane wale sawaal</h2>
          <Faq title={config.title} description={config.description} faqs={faqData} />
        </div>
      </section>

      <section className="related_tools">
        <div className="max-width">
          <h2 className="subtitle">Aur calculators</h2>
          <RelatedTools tools={relatedToolsData} />
        </div>
      </section>
    </>
  )
}